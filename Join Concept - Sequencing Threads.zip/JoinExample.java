
import java.util.ArrayList;

public class JoinExample 
{
	   public static void main(String[] args) 
	   {
            //TODO - Implement the main method to access and sequence the threads here
            Thread threads[]=new Thread[3];
            threads[0]=new Thread(new MyClass(),"Mercury");
            threads[1]=new Thread(new MyClass(),"Earth");
            threads[2]=new Thread(new MyClass(),"Venus");
            for(int i=0;i<3;i++){
                threads[i].start();
            }
	   }
}


// TODO - Create the class Myclass which implements the runnable interface here
// Implememt the run method in the MyClass
class MyClass implements Runnable{
    public static ArrayList<String> tact=new ArrayList<String>();
    @Override
    public void run(){
        synchronized(MyClass.class){
            try{
                tact.add(Thread.currentThread().getName());
                System.out.println(tact.get(tact.size()-1));
                Thread.currentThread().sleep(1000);
                System.out.println("Thread ended: "+tact.get(tact.size()-1));
            }catch(InterruptedException e){
                
            }
            if(tact.size()==3)
            System.out.println("All three threads have finished execution");
        }
    }
}
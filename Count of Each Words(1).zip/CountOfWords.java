//import the necessary packages if needed
     import java.util.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class CountOfWords
{
   public static void main (String[] args) {
       Scanner sc=new Scanner(System.in);
       CountOfWords cw=new CountOfWords();
       String text=sc.nextLine();
       text=text+" ";
       text=text.toLowerCase();
       int r=cw.countword(text);
       int ct=0,flag=0;
       System.out.println("Number of words "+r);
       String f[]=new String[r];
       int g[]=new int[r];
       String t="";
       int l=text.length();
       for(int i=0;i<l;i++){
           char c=text.charAt(i);
           if(c!=' ' && c!=',' && c!=';' && c!=':' && c!='?' && c!='!' && c!='.'){
               t=t+c;
           }
           else{
               if(t=="")
               continue;
               int cnt=cw.count(text,t);
               if(ct==0){
                   f[ct]=t;
                   g[ct]=cnt;
                   ct++;
               }
               else{
                   for(int j=0;j<ct;j++){
                       if(f[j].equalsIgnoreCase(t))
                       flag=1;
                   }
                   if(flag==0){
                       f[ct]=t;
                       g[ct]=cnt;
                       ct++;
                   }
                   t="";
                   flag=0;
               }
               t="";
           }
       }
           for(int i=0;i<(ct);i++){
               for(int j=(i+1);j<ct;j++){
                   if(f[j].compareTo(f[i])<0){
                       String temp=f[i];
                       int temp1=g[i];
                       f[i]=f[j];
                       g[i]=g[j];
                       f[j]=temp;
                       g[j]=temp1;
                   }
               }
               
           }
           System.out.println("Words with the count");
           for(int i=0;i<ct;i++){
               System.out.println(f[i]+": "+g[i]);
           }
       }
       public int count(String txt,String word){
           int l=txt.length();
           String t="";
           int count=0;
           for(int i=0;i<l;i++){
               char c=txt.charAt(i);
               if(c!=' ' && c!=';' && c!=',' && c!=':' && c!='.' && c!='?' && c!='!'){
                   t=t+c;
               }
               else{
                   if(t.equalsIgnoreCase(word)){
                       count++;
                   }
                   t="";
                   }
               }
               return count;
           }
           public int countword(String text){
               int l=text.length();
               int count=0;
               for(int i=0;i<l;i++){
                   char c=text.charAt(i);
                   if(c==32||c==','||c==';'||c=='.'||c==':'||c=='?'||c=='!'){
                       char k=text.charAt((i-1));
                       if(k==32||k==','||k==';'||k==':'||k=='.'||k=='?'||k=='!')
                       continue;
                       count++;
                   }
               }
               return (count);
           }
       }

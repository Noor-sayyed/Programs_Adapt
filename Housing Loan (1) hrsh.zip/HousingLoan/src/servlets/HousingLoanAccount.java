package servlets;

public class HousingLoanAccount {
    String housingLoanId,loanHolderName,loanType;
    double housingLoanAmount;
    int loanTenure;
    public void setLoanId(String id){
        this.housingLoanId=id;
    }
    public void setHolderName(String name){
        this.loanHolderName=name;
    }
    public void setLoanType(String type){
        this.loanType=type;
    }
    public void setHousingLoanAmount(double amount){
        this.housingLoanAmount=amount;
    }
    public void setLoanTenure(int tenure){
        this.loanTenure=tenure;
    }
    public String getLoadId(){
        return this.housingLoanId;
    }
    public String getHolderName(){
        return this.loanHolderName;
    }
    public String getLoanType(){
        return this.loanType;
    }
    public double getHousingLoanAmount(){
        return this.housingLoanAmount;
    }
    public int getLoanTenure(){
        return this.loanTenure;
    }
}

package servlets;

import java.io.*;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class HousingLoanServlet
 */
@WebServlet(urlPatterns={"/HousingLoanServlet"},
initParams = {
	    @WebInitParam (name = "rateOfInterestFixed", value = "8.35%"),
	    @WebInitParam (name = "rateOfInterestFloat", value = "9.35%"),
			})
public class HousingLoanServlet extends HttpServlet {
    public String rateOfInterestFloat="9.35%";
    public String rateOfInterestFixed="8.35%";
	private static final long serialVersionUID = 1L;
	public static int id=0;

    public HousingLoanServlet() {
        super();
       
       // write code here
    }
    
    @Override
    public void init(ServletConfig config) throws ServletException
    {
 	   super.init(config);
 	   
 	   // Write the code
 	   
    }
    

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	PrintWriter writer=response.getWriter();
	String check=request.getParameter("housingLoanType");
	double amount=Double.parseDouble(request.getParameter("housingLoanAmount"));
	int tenure=Integer.parseInt(request.getParameter("housingLoanTenure"));
	String holder=request.getParameter("loanHolderName");
	if(check=="Fixed"){
	    writer.print(myPrint(id,amount,holder,tenure,check,this.rateOfInterestFixed));
	}
	else if(check=="Float"){
	    writer.print(myPrint(id,amount,holder,tenure,check,this.rateOfInterestFloat));
	}
	id++;
	}
public String myPrint(int id,double housingamount,String holderName,int loantenure,String type,String roi){
    return "<html><head><style>body{background-color:#6C9;}h3{color:blue; margin-left:10px;}</style></head><body><img src=\"hll.png\" width=\"300\" height=\"200\"/><br><h3>HOUSING LOAN DETAILS<br>Loan ID: LID100"+id+"<br>Loan Holder's Name: "+holderName+"<br>Loan Amount: "+housingamount+"<br>Loan Tenure: "+loantenure+"<br>Loan Type: "+type+"<br>Loan ROI: "+roi+"</h3></body></html>";
}
	


}

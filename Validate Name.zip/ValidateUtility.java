import java.util.*;
public class ValidateUtility
{
    public static void main(String args[])
    {
        //fill code here
        Scanner sc=new Scanner(System.in);
        String name=sc.nextLine();
        String productName=sc.nextLine();
        if(validateEmployeeName().validateName(name)){
            System.out.println("Employee name is valid");
        }
        else
        {
            System.out.println("Employee name is invalid");
        }
        if(validateProductName().validateName(productName)){
            System.out.println("Product name is valid");
        }
        else{
            System.out.println("Product name is invalid");
        }
    }
    
    public static Validate validateEmployeeName() 
    {
        //fill code here
        return name->name.matches("^[A-Za-z ]{5,20}$")?true:false;
    }
    
    public static Validate validateProductName() 
    {
        //fill code here
        return name->name.matches("[A-Za-z ]{1}[0-9]{5}$")?true:false;
    }
}
import java.util.*;
public class Main
{
    Library l=new Library();
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        Main m=new Main();
        while(true)
        {
            System.out.println("1.Add Book");
            System.out.println("2.Display all book details");
            System.out.println("3.Search Book by author");
            System.out.println("4.Count number of books-by book name");
            System.out.println("5.Exit");
            System.out.println("Enter your choice:");
            int ch=sc.nextInt();
            if(ch==1)
            m.insert();
            else if(ch==2)
            m.disp();
            else if(ch==3)
            m.sauthor();
            else if(ch==4)
            m.cbook();
            else if(ch==5)
            System.exit(0);
        }
    }
    public void insert(){
        Scanner sc=new Scanner(System.in);
        Book b=new Book();
        System.out.println("Enter the isbn no:");
        int isb=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the book name:");
        String bkname=sc.nextLine();
        System.out.println("Enter the author name:");
        String author=sc.nextLine();
        b.setIsbnno(isb);
        b.setBookName(bkname);
        b.setAuthor(author);
        l.addBook(b);
    }
    public void disp(){
        ArrayList<Book> bk=l.viewAllBooks();
        for(Book b:bk)
        {
            System.out.println("ISBN no:"+b.getIsbnno());
            System.out.println("Book name:"+b.getBookName());
            System.out.println("Author name:"+b.getAuthor());
        }
    }
    public void cbook(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the book name:");
        String name=sc.nextLine();
        int c=l.countnoofbook(name);
        System.out.println("Available Stock:"+c);
    }
    public void sauthor(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the author name:");
        String name=sc.nextLine();
        ArrayList<Book> bk=l.viewBooksByAuthor(name);
        if(bk.size()==0)
        System.out.println("None of the book published by the author"+name);
        else{
            for(Book b:bk){
                System.out.println("ISBN no:"+b.getIsbnno());
                System.out.println("Book name:"+b.getBookName());
                System.out.println("Author name:"+b.getAuthor());
            }
        }
    }
}
import java.util.*;
public class Main{
    Library l=new Library();
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        Main m=new Main();
        while(true){
            System.out.println("1.Add Member");
            System.out.println("2.View All Members");
            System.out.println("3.Search Member by address");
            System.out.println("4.Exit");
            System.out.println("Enter your choice");
            int ch=sc.nextInt();
            sc.nextLine();
            if(ch==1)
            m.add();
            else if(ch==2)
            m.viewall();
            else if(ch==3)
            m.view();
            else if(ch==4)
            System.exit(0);
        }
    }
    public void add(){
        Scanner sc=new Scanner(System.in);
        Member m=new Member();
        System.out.println("Enter the id:");
        int id=sc.nextInt();
        sc.nextLine();
        System.out.println("Enter the name:");
        String name=sc.nextLine();
        System.out.println("Enter the address:");
        String add=sc.nextLine();
        m.setMemberId(id);
        m.setMemberName(name);
        m.setAddress(add);
        l.addMember(m);
    }
    public void viewall(){
        List<Member> list=l.viewAllMembers();
        if(list.size()==0)
        System.out.println("The list is empty");
        else{
            for(Member m:list){
                System.out.println("Id:"+m.getMemberId());
                System.out.println("Name:"+m.getMemberName());
                System.out.println("Address:"+m.getAddress());
            }
        }
    }
    public void view()
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the address:");
        String add=sc.nextLine();
        List<Member> list=l.viewMembersByAddress(add);
        if(list.size()==0)
        System.out.println("None of the member is from "+add);
        for(Member m:list)
        {
            System.out.println("Id:"+m.getMemberId());
            System.out.println("Name:"+m.getMemberName());
            System.out.println("Address:"+m.getAddress());
        }
    }
}
import java.util.*;
public class Library{
    
    private List<Member> memberList=new ArrayList<Member>();
    public List<Member> getMemberList(){
        return memberList;
    }
    public void setMemberList(List<Member> memberList){
        this.memberList=memberList;
    }
    public void addMember(Member memberObj){
        memberList.add(memberObj);
    }
    public List<Member> viewMembersByAddress(String address){
        List<Member> l=new ArrayList<Member>();
        for(Member m:memberList){
            if(m.getAddress().equals(address)){
                l.add(m);
            }
        }
        return l;
    }
    public List<Member> viewAllMembers(){
        return memberList;
    }
}
import java.util.*;
public class Calculator
{
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        int a=sc.nextInt();
        int b=sc.nextInt();
        System.out.println("The sum is "+performAddition().performCalculation(a,b));
        System.out.println("The difference is "+performSubtraction().performCalculation(a,b));
        System.out.println("The product is "+performProduct().performCalculation(a,b));
        System.out.println("The division value is "+performDivision().performCalculation(a,b));
    }
    public static Calculate performAddition(){
        return (a,b)->a+b;
    }
    public static Calculate performSubtraction(){
        return (a,b)->a-b;
    }
    public static Calculate performProduct(){
        return (a,b)->a*b;
    }
    public static Calculate performDivision(){
        return (a,b)->a/b;
    }
}
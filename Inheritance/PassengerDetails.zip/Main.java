import java.util.*;
public class Main
{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the no.of passengers:");
        int num=sc.nextInt();
        Passenger obj[]=new Passenger[num];
        int ticketid;
        String name,gender,address;
        for(int i=0;i<num;i++)
        {
            System.out.println("Passenger "+(i+1));
            System.out.println("Enter the ticketid:");
            ticketid=sc.nextInt();
            sc.nextLine();
            System.out.println("Enter the name:");
            name=sc.nextLine();
            System.out.println("Enter the gender:");
            gender=sc.nextLine();
            System.out.println("Enter the address:");
            address=sc.nextLine();
            obj[i]=new Passenger(ticketid,name,gender,address); 
            //System.out.println(obj);
        }
        for(int i=0;i<num;i++)
        System.out.println(obj[i]);
    }
}
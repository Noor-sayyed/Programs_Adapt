import java.util.*;
public class Main{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        Customer obj[]=new Customer[2];
        /*obj[0]=new Customer();
        obj[1]=new Customer();*/
        for(int i=0;i<2;i++)
        {
            System.out.println("Enter the name:");
            String name=sc.nextLine();
            System.out.println("Enter the panno:");
            String panno=sc.nextLine();
            System.out.println("Enter the emailid:");
            String emailid=sc.nextLine();
            System.out.println("Enter the salary:");
            int salary=sc.nextInt();
            sc.nextLine();
            obj[i]=new Customer(name,panno,emailid,salary);
        }
        if(obj[0].equals(obj[1]))
        System.out.println("Both the objects are equal.");
        else
        System.out.println("Both the objects are not equal.");
    }
}
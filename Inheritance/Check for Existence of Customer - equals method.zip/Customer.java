public class Customer
{
    private String name,panno,emailid;
    private int salary;
    public Customer(String name,String panno,String emailid,int salary)
    {
        this.name=name; this.panno=panno; this.emailid=emailid; this.salary=salary;
    }
    public void setName(String name)
    {
        this.name=name;
    }
    public void setPanno(String panno)
    {
        this.panno=panno;
    }
    public void setEmailid(String emailid)
    {
        this.emailid=emailid;
    }
    public void setSalary(int salary)
    {
        this.salary=salary;
    }
    public String getName()
    {
        return name;
    }
    public String getPanno()
    {
        return panno;
    }
    public String getEmailid()
    {
        return emailid;
    }
    public int getSalary()
    {
        return salary;
    }
    public boolean equals(Object o)
    {
        Customer c=(Customer)o;
        //return String.compare(name,c.name)==0 && String.compare(panno,c.panno)==0 && salary==c.salary;
        return panno.equals(c.panno) && emailid.equals(c.emailid);
    }
}
import java.util.*;
public class Main{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        PermanentEmployee obj=new PermanentEmployee();
        System.out.println("Enter the name:");
        obj.setName(sc.nextLine());
        System.out.println("Enter the salary:");
        float salary=sc.nextFloat();
        obj.setSalary(salary);
        //obj.salary1=salary;
        System.out.println("Enter the pfpercentage:");
        float pfpercentage=sc.nextFloat();
        obj.setPfpercentage(pfpercentage);
        //obj.pfp=pfpercentage;
        if(obj.validateInput())
        {
            obj.findNetSalary();
        }
        else
        {
            System.out.println("Error!!! Unable to calculate the NetSalary.");
            System.exit(0);
        }
        System.out.println("Employee Name:"+obj.getName());
        System.out.printf("PF Amount:%.2f\n",obj.getPfamount());
        System.out.printf("Netsalary:%.2f",obj.getNetsalary());
    }
}
public class PermanentEmployee extends Employee
{
    //float salary1,pfp;
    private float pfpercentage,pfamount;
    public void setPfpercentage(float pfpercentage)
    {
        this.pfpercentage=pfpercentage;
    }
    public void setPfamount(float pfamount)
    {
        this.pfamount=pfamount;
    }
    public boolean validateInput()
    {
        if(getSalary()>0 && getPfpercentage()>=0)
        return true;
        else
        return false;
    }
    public void findNetSalary()
    {
        float salary=getSalary();
        float pfamount=salary*pfpercentage/100;
        setPfamount(pfamount);
        setNetsalary(salary-pfamount);
    }
    public float getPfpercentage()
    {
        return pfpercentage;
    }
    public float getPfamount()
    {
        return pfamount;
    }
}
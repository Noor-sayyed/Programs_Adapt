public class Employee
{
    private String name;
    private float salary,netsalary;
    public void setName(String name)
    {
        this.name=name;
    }
    public void setSalary(float salary)
    {
        this.salary=salary;
    }
    public void setNetsalary(float netsalary)
    {
        this.netsalary=netsalary;
    }
    public String getName()
    {
        return name;
    }
    public float getSalary()
    {
        return salary;
    }
    public float getNetsalary()
    {
        return netsalary;
    }
}
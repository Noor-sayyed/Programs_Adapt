import java.util.*;
public class Main{
    public static void main (String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the type of shape :");
        String shape=sc.nextLine();
        if(shape.equalsIgnoreCase("circle"))
        {
            //Circle obj=new Circle();
            System.out.println("Enter the radius :");
            float radius=sc.nextFloat();
            Circle obj=new Circle(radius);
            System.out.printf("The area of Circle is : %.2f",obj.calculateArea());
        }
        else if(shape.equalsIgnoreCase("rectangle"))
        {
            //Rectangle obj=new Rectangle();
            System.out.println("Enter the length :");
            float length=sc.nextFloat();
            System.out.println("Enter the breadth :");
            float breadth=sc.nextFloat();
            Rectangle obj=new Rectangle(length,breadth);
            System.out.printf("The area of Rectangle is : %.2f",obj.calculateArea());
        }
        else if(shape.equalsIgnoreCase("triangle"))
        {
            //Triangle obj=new Triangle();
            System.out.println("Enter the base :");
            float base=sc.nextFloat();
            System.out.println("Enter the height :");
            float height=sc.nextFloat();
            Triangle obj=new Triangle(base,height);
            System.out.printf("The area of Triangle is : %.2f", obj.calculateArea());
        }
    }
}
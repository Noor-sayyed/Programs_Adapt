public class Circle extends Shape
{
    private float radius;
    public Circle(float radius)
    {
        this.radius=radius;
    }
    public void setRadius(float radius)
    {
        this.radius=radius;
    }
    public float getRadius(float radius)
    {
        return radius;
    }
    public double calculateArea()
    {
        return Math.PI*radius*radius;
    }
}

import java.util.ArrayList;
import java.util.Random;

// re-implement Dice class extending Thread class
public class Dice extends Thread
{
    private Random random;
    private int rolls;
    private String name;
    static ArrayList <String> tact=new ArrayList<String>();
    
    // Implement the constructor and the run method according to the specifications   
    public Dice(int n,String name){
        this.rolls=n;
        this.name=name;
        random=new Random();
    }
    @Override
    public void run(){
        synchronized(this){
            int sum=0;
            for(int roll=0;roll<this.rolls;roll++){
                sum+=random.nextInt(6)+1;
            }
            tact.add("Average roll of "+this.name+" : "+sum/this.rolls);
            if(tact.size()==2)
            {
                for(String element:Dice.tact){
                    System.out.println(element);
                }
            }
        }
    }

    public static void main(String[] args)
    {
        Dice d = new Dice(6,"Player 1");
        Dice d2 = new Dice(6,"Player 2");
        d.start();
        d2.start();

    }

}

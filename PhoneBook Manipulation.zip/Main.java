import java.util.*;
public class Main{
    PhoneBook ph = new PhoneBook();
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        Main m = new Main();
        while(true){
            System.out.println("Menu");
            System.out.println("1.Add Contact");
            System.out.println("2.Display all contacts");
            System.out.println("3.Search contact by phone");
            System.out.println("4.Remove contact");
            System.out.println("5.Exit");
            System.out.println("Enter your choice:");
            int ch = sc.nextInt();
            if(ch==1)
            m.add();
            else if (ch==2)
            m.display();
            else if (ch==3)
            m.cPhone();
            else if (ch==4)
            m.remove();
            else if (ch==5)
            System.exit(0);
        }
    }
    public void add(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Add a Contact:");
        System.out.println("Enter the First Name:");
        String first = sc.nextLine();
        System.out.println("Enter the Last Name:");
        String last = sc.nextLine();
        System.out.println("Enter the Phone No:");
        Long phono = sc.nextLong();
        System.out.println("Enter the Email:");
        sc.nextLine();
        String email = sc.nextLine();
        Contact c = new Contact(first,last,phono,email);
        ph.addContact(c);
    }
    public void display(){
        List<Contact> list = ph.viewAllContacts();
        if(list.size()==0)
        System.out.println("List is empty");
        else{
            System.out.println("The contacts in the List are:");
            for(Contact c:list){
                System.out.println("First Name: "+c.getFirstName());
                System.out.println("Last Name: "+c.getLastName());
                System.out.println("Phone No.: "+c.getPhoneNumber());
                System.out.println("Email: "+c.getEmailId());
            }
        }
    } 
    public void cPhone(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Phone number to search contact:");
        long phono = sc.nextLong();
        Contact c = ph.viewContactGivenPhone(phono);
        if(c==null)
        System.out.println("There is no contact details");
        else{
            System.out.println("The contact is:");
            System.out.println("First Name: "+c.getFirstName());
            System.out.println("Last Name: "+c.getLastName());
            System.out.println("Phone No.: "+c.getPhoneNumber());
            System.out.println("Email: "+c.getEmailId());
        }
    }
    public void remove(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Phone number to remove :");
        long phono = sc.nextLong();
        System.out.println("Do you want to remove the contact(Y/N):");
        char ch = sc.next().charAt(0);
        boolean option = false;
        if(ch=='Y' || ch=='y')
        option = ph.removeContact(phono);
        if(option)
        System.out.println("The contact is successfully deleted.");
        else
        System.out.println("The phone number not available.");
    }
}
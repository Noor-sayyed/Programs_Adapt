import java.util.*;
public class PhoneBook{
    private List<Contact> phoneBook = new ArrayList<Contact>();
    public void setPhoneBook(List<Contact> phoneBook){
        this.phoneBook = phoneBook;
    }
    public List<Contact> getPhoneBook(){
        return phoneBook;
    }
    public void addContact(Contact contactObj){
        phoneBook.add(contactObj);
    }
    public List<Contact> viewAllContacts(){
        return phoneBook;
    }
    public Contact viewContactGivenPhone(long phoneNumber){
        Contact c = null;
        for(Contact con:phoneBook){
            if(con.getPhoneNumber()==phoneNumber)
            c = con;
        }
        return c;
    }
    public boolean removeContact(long phoneNumber){
       int flag = 0;
       for(Contact c:phoneBook){
           if(c.getPhoneNumber()==phoneNumber){
               phoneBook.remove(c);
               flag = 1;
               break;
           }
       }
       if(flag==1)
       return true;
       else
       return false;
    }
}
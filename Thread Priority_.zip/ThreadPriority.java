import java.util.*;
class ThreadPriority extends Thread
{
    public ThreadPriority(String name)
    {
        this.setName(name);
    }
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Thread 1 name :");
        String t1n=sc.nextLine();
        System.out.println("Enter Thread 2 name :");
        String t2n=sc.nextLine();
        System.out.println("Enter Thread 3 name :");
        String t3n=sc.nextLine();
        ThreadPriority t1=new ThreadPriority(t1n);
        ThreadPriority t2=new ThreadPriority(t2n);
        ThreadPriority t3=new ThreadPriority(t3n);
        System.out.println("Thread priority of: "+t1.getName()+" "+t1.getPriority());
        System.out.println("Thread priority of: "+t2.getName()+" "+t2.getPriority());
        System.out.println("Thread priority of: "+t3.getName()+" "+t3.getPriority());
        System.out.println("Enter Thread 1 Priority :");
        int t1p=sc.nextInt();
        System.out.println("Enter Thread 2 Priority :");
        int t2p=sc.nextInt();
        System.out.println("Enter Thread 3 Priority :");
        int t3p=sc.nextInt();
        t1.setPriority(t1p);
        t2.setPriority(t2p);
        t3.setPriority(t3p);
        System.out.println("Thread priority of "+t1.getName()+" "+t1.getPriority());
        System.out.println("Thread priority of "+t2.getName()+" "+t2.getPriority());
        System.out.println("Thread priority of "+t3.getName()+" "+t3.getPriority());
        System.out.println(Thread.currentThread().getName()+"Main thread priority : "+Thread.currentThread().getPriority());
        Thread.currentThread().setPriority(10);
        System.out.println("New Main thread priority : "+Thread.currentThread().getPriority());
    }
}
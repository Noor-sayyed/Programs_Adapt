import java.util.*;
public class ThreadJoin{
    public static void main (String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("How many numbers to sort ?");
        int n=sc.nextInt();
        int arr[]=new int[n];
        System.out.println("Enter the numbers");
        for(int i=0;i<n;i++){
            arr[i]=sc.nextInt();
            
        }
        System.out.println("Enter the element to be searched");
        int x=sc.nextInt();
        MyThread t1=new MyThread(arr);
        t1.setName("bubbleSort");
        MyThread t2=new MyThread(arr);
        t2.setName("search");
        t2.x=x;
        t1.start();
        t2.start();
        
    }
}
class Operation{
    public synchronized int search(int arr[],int x){
        for(int i=0;i<arr.length;i++){
            if(arr[i]==x)
            return i;
        }
        return -1;
    }
    public synchronized void bubbleSort(int arr[]){
        Arrays.sort(arr);
        
    }
    public synchronized void printArray(int arr[]){
        for(int element: arr){
            System.out.print(element+" ");
        }
        System.out.println("");
    }
}
class MyThread extends Thread{
    public int arr[];
    public int x;
    public MyThread(int arr[]){
        this.arr=arr;
    }
    @Override
    public void run(){
        Operation o=new Operation();
        synchronized(this){
            if(this.getName().equals("bubbleSort")){
                System.out.println("Starting Thread Sort");
                System.out.println("Starting Thread Search");
                o.bubbleSort(this.arr);
                System.out.println("Thread Sort exiting");
                System.out.println("The sorted array is");
                o.printArray(this.arr);
            }
            if(this.getName().equals("search")){
                int index=o.search(this.arr,this.x);
                System.out.println("Element is present at Position "+(index+1));
                System.out.println("Thread Search exiting.");
            }
        }
    }
    @Override
    public void start(){
        super.start();
    }
}
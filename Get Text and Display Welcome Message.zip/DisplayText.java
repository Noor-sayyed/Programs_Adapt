import java.util.Scanner;
@FunctionalInterface
public interface DisplayText
{
    public void displayText(String text);
    public default String getInput(){
        Scanner sc=new Scanner(System.in);
        return sc.nextLine();
    }
}
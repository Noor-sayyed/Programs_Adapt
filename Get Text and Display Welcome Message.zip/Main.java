public class Main
{
    public static void main(String args[])
    {
        DisplayText display=welcomeMessage();
        String text=display.getInput();
        display.displayText(text);
    }
    public static DisplayText welcomeMessage(){
        DisplayText display=text->System.out.println("Welcome "+text);
        return display;
    }
}
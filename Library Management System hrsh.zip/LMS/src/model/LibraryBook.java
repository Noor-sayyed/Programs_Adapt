package model;

public class LibraryBook {
    
    
    
    
    
 //Write the Attributes, Setters and Getters  
    
    
    
    
    
    
    
    
}    
    
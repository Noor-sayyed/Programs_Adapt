package book;

import javax.servlet.http.HttpServlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.annotation.WebServlet;
import java.io.PrintWriter;

@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	public static int id=1;

	public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	   PrintWriter writer=resp.getWriter();
	   String  c=req.getParameter("check");
	   if(c=="addid"){
	       String msg="<html><head><style>body{background-color:#6C9;}h3{color:blue;margin-left:10px;}</style></head><body><h3>Successfully Added Book "+id+"</h3></body></html>";
	   writer.print(msg);
	   id++;}
    //Write the code 	    
	    
	    
	    
	    
	}
}	
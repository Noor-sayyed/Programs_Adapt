//import the necessary packages if needed
import java.util.*;
import java.util.regex.*;
@SuppressWarnings("unchecked")//Do not delete this line
public class UniqueWords
{
    public static void main (String[] args) {
        Scanner sc = new Scanner(System.in);
        List<String> list = new ArrayList<String>();
        Set<String> set = new TreeSet<String>();
        System.out.println("Enter Student's Article");
        String s = sc.nextLine();
        String str[] = s.split("[\\s,;:.?!]+");
        for(String word:str){
            String w = word.toLowerCase();
            list.add(w);
            set.add(w);
        }
        System.out.println("Number of words "+list.size());
        System.out.println("Number of unique words "+set.size());
        System.out.println("The words are");
        int n = 1;
        for(String word:set){
            System.out.println(n+". "+word);
            n++;
        }
    }
}
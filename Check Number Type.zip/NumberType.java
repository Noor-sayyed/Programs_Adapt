public interface NumberType
{
    public boolean checkNumberType(int number);
}
import java.util.*;
public class NumberTypeUtility
{
   public static void main (String[] args) {
       Scanner sc=new Scanner(System.in);
       int num=sc.nextInt();
       NumberType func=isOdd();
       if(func.checkNumberType(num))
            System.out.println(num+" is odd");
       else
            System.out.println(num+" is not odd");
   }
   public static NumberType isOdd(){
       return num->num%2==0?false:true;
   }
}
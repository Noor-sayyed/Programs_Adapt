package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculatorServlet
 */

@WebServlet("/CalculatorServlet")
public class CalculatorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public CalculatorServlet() {
        super();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
            int res=0;
            String a=request.getParameter("number1");
            String b=request.getParameter("number2");
            String op=request.getParameter("typeofop");
            int x=Integer.parseInt(a);
            int y=Integer.parseInt(b);
            res=Calculator.performCalculation(x,y,op);
            PrintWriter writer=response.getWriter();
            writer.append("The result is "+res);

	}
	

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}









































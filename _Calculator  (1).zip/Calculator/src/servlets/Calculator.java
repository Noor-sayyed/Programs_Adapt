package servlets;

public class Calculator {

public static int performCalculation(int x,int y,String tp)
{
    if("+".equals(tp))
    return x+y;
    else if("-".equals(tp))
    return x-y;
    else if("*".equals(tp))
    return x*y;
    else
    return x/y;
}

}
